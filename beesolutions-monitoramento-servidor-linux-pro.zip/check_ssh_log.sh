#!/bin/bash

# Desenvolvido por: Bee Solutions
# Autor: Fernando Almondes
# Data: 08/03/2024 14:44

cat /var/log/auth.log | tail -10
